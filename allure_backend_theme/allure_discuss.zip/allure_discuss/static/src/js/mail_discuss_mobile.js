odoo.define('allure_discuss.DiscussMobile', function(require) {
    "use strict";

const config = require('web.config');

if (!config.device.isMobile) {
    return;
}

const core = require('web.core');
var Discuss = require('mail.Discuss');
const QWeb = core.qweb;
const _t = core._t;

Discuss.include({
    contentTemplate: 'mail.discuss_mobile',
    events: _.extend(Discuss.prototype.events, {
        'click .o_mail_mobile_tab': function(e) {
            var type = $(e.currentTarget).data('type');
            if (type === 'mailbox') {
                var inbox = this.call('mail_service', 'getMailbox', 'inbox');
                this._setThread(inbox);
            }
            this._updateContent(type);
        },
        'click .o_mailbox_inbox_item': function(e) {
            var mailboxID = $(e.currentTarget).data('type');
            this._setThread(mailboxID);
            this._updateContent(this._thread.getID());
        },
        'click .o_mail_preview': function(e) {
            var threadID = $(e.currentTarget).data('preview-id');
            this.call('mail_service', 'openThreadWindow', threadID);
        },
    }),
    init: function() {
        this._super.apply(this, arguments);
        this._currentState = this._defaultThreadID;
    },
    start: function() {
        this._$mainContent = this.$('.o_mail_discuss_content');
        return this._super.apply(this, arguments).then(() => {
            this._updateControlPanel();
        });
    },
    on_attach_callback: function() {
        if (this._thread && this._isInInboxTab()) {
            this._threadWidget.scrollToPosition(this._threadsScrolltop[this._thread.getID()]);
        }
    },
    on_detach_callback: function() {
        if (this._isInInboxTab()) {
            this._threadsScrolltop[this._thread.getID()] = this._threadWidget.getScrolltop();
        }
    },
    _initThreads: function() {
        return this._updateThreads();
    },
    _isInInboxTab: function() {
        return _.contains(['mailbox_inbox', 'mailbox_starred', 'mailbox_history'], this._currentState);
    },
    _renderButtons: function() {
        var self = this;
        this._super.apply(this, arguments);
        _.each(['dm_chat', 'multi_user_channel'], function(type) {
            var selector = '.o_mail_discuss_button_' + type;
            self.$buttons.on('click', selector, self._onAddThread.bind(self));
        });
    },
    _restoreThreadState: function() {
        if (this._isInInboxTab()) {
            this._super.apply(this, arguments);
        }
    },
    _selectMessage: function() {
        this._super.apply(this, arguments);
        this.$('.o_mail_mobile_tabs').addClass('o_hidden');
    },
    _setThread: function(threadID) {
        var thread = this.call('mail_service', 'getThread', threadID);
        this._thread = thread;
        if (thread.getType() !== 'mailbox') {
            this.call('mail_service', 'openThreadWindow', threadID);
            return Promise.resolve();
        } else { return this._super.apply(this, arguments); }
    },
    _storeThreadState: function() {
        if (this._thread && this._isInInboxTab()) {
            this._super.apply(this, arguments);
        }
    },
    _unselectMessage: function() {
        this._super.apply(this, arguments);
        this.$('.o_mail_mobile_tabs').removeClass('o_hidden');
    },
    _updateThreads: function() {
        return this._updateContent(this._currentState);
    },
    _updateContent: function(type) {
        var self = this;
        var inMailbox = _.contains(['mailbox_inbox', 'mailbox_starred', 'mailbox_history'], type);
        if (!inMailbox && this._isInInboxTab()) {
            this._storeThreadState();
        }
        var previouslyInInbox = this._isInInboxTab();
        this._currentState = type;
        var def;
        if (inMailbox) {
            def = this._fetchAndRenderThread();
        } else {
            var allChannels = this.call('mail_service', 'getChannels');
            var channels = _.filter(allChannels, function(channel) { return channel.getType() === type; });
            def = this.call('mail_service', 'getChannelPreviews', channels);
        }
        return Promise.resolve(def).then(function(previews) {
            if (inMailbox) {
                if (!previouslyInInbox) {
                    self.$('.o_mail_discuss_tab_pane').remove();
                    self._$mainContent.append(self._threadWidget.$el);
                    self._$mainContent.append(self._extendedComposer.$el);
                }
                self._restoreThreadState();
            } else {
                self._threadWidget.$el.detach();
                self._extendedComposer.$el.detach();
                var $content = $(QWeb.render('mail.discuss.MobileTabPane', {
                    previews: previews,
                    type: type,
                }));
                self._prepareAddThreadInput($content.find('.o_mail_add_thread input'), type);
                self._$mainContent.html($content);
            }
            self.$buttons.find('button').removeClass('d-block').addClass('d-none');
            self.$buttons.find('.o_mail_discuss_button_' + type).removeClass('d-none').addClass('d-block');
            self.$buttons.find('.o_mail_discuss_button_mark_all_read').toggleClass('d-none', type !== 'mailbox_inbox').toggleClass('d-block', type === 'mailbox_inbox');
            self.$buttons.find('.o_mail_discuss_button_unstar_all').toggleClass('d-none', type !== 'mailbox_starred').toggleClass('d-block', type === 'mailbox_starred');
            if (inMailbox) {
                self.$('.o_mail_discuss_mobile_mailboxes_buttons').removeClass('o_hidden');
                self.$('.o_mailbox_inbox_item').removeClass('btn-primary').addClass('btn-secondary');
                self.$('.o_mailbox_inbox_item[data-type=' + type + ']').removeClass('btn-secondary').addClass('btn-primary');
            } else {
                self.$('.o_mail_discuss_mobile_mailboxes_buttons').addClass('o_hidden');
            }
            self.$('.o_mail_mobile_tab').removeClass('active');
            type = _.contains(['mailbox_inbox', 'mailbox_starred', 'mailbox_history'], type) ? 'mailbox_inbox' : type;
            self.$('.o_mail_mobile_tab[data-type=' + type + ']').addClass('active');
        }).then(() => { return Promise.resolve(); });
    },
    _onAddThread: function() {
        this.$('.o_mail_add_thread').show().find('input').focus();
    },
});

});