# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name': 'Allure Discuss',
    'category': "Discuss",
    'version': '1.0',
    'summary': 'Responsive view for Discuss',
    'description': """
        This modules make Discuss view compatible with all the device size.
    """,
    'author': 'Synconics Technologies Pvt. Ltd.',
    'website': 'www.synconics.com',
    'depends': ['mail','allure_backend_theme'],
    'data': [
        'views/assets_registry.xml',
    ],
    'license': 'OPL-1',
    'installable': True,
    'auto_install': False,
    'application': False,
}
